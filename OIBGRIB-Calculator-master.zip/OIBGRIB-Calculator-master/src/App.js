import Calculator from "./components/Calculator";
function App() {
  return (
    <>
      <Calculator />
    </>
  );
}

export default App;
